```
$ python3 CHAP_client.py                                                                                       
Please provide me a sha256(password+bPlXG)!
Continue
```

```
$ python3 CHAP_server.py                                                                                       14:16:50
Server started!
Got new auth attempt '1de266ab81d1beea48406c84a9b4af7c7a7a608af8cfe2066b4f09e8c44b13db'
Access granted!
```
