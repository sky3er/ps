```
$ python3 PAP_server.py                                                                                         
Server started!
Got new auth attempt 'letmein'
Access granted!
```

```
$ python3 PAP_client.py
Please provide me a password!
Continue
```
