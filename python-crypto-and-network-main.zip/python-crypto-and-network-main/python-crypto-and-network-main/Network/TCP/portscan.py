from scapy.all import IP, TCP, sr, sr1

target_ip = ["192.168.1.1" , "192.168.1.167"]  # Список целевых IP адрес
port_range = [22,80,443,8080]  # Порты для сканирования

for target in target_ip:  # Цикл по IP
    for port in port_range: # Цикл по портам
        ip_packet = IP(dst=target)
        tcp_packet = TCP(dport=port, flags="S")
    
    # Отправляем пакет и получаем ответ
        response = sr1(ip_packet / tcp_packet, timeout=0.5, verbose=0)
    
    # Обрабатываем полученный ответ
        if response:
            if response.haslayer(TCP) and response[TCP].flags == 18:  # TCP SYN-ACK
                print(f"{ip_packet}: {port} open")
            else:
                print(f"{ip_packet}: {port} closed")