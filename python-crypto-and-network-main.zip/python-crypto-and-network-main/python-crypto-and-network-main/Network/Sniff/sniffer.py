from scapy.all import *

# Укажите имя сетевого интерфейса
pkts = sniff(iface='Ethernet', filter='tcp[tcpflags] == 0x02' , prn=lambda x:x.summary())
